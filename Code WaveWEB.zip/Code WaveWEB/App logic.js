let gameFont;
let state = "whiteBoxes";  // 'whiteBoxes' -> 'coloredBoxes' -> 'recipe'
let boxes = [];
let labels = ["Italian", "Mexican", "Chinese", "Thai", "Indian", "Japanese"];  // Cuisines
let cuisineColors = [];  // Fixed unique color for each cuisine
let selectedCuisineIndex = -1; // Which cuisine was clicked

// This tracks whether the recipes are unlocked in the second set
let unlockedBoxes = [true, false, false, false, false, false]; // Only the first box is unlocked initially

function preload() {
    gameFont = loadFont("Akhenaton-LYLD.ttf");
}

function setup() {
    createCanvas(1535, 787);

    // Set up box positions
    boxes = [
        { x: 50, y: 100 },
        { x: 550, y: 100 },
        { x: 1050, y: 100 },
        { x: 50, y: 450 },
        { x: 550, y: 450 },
        { x: 1050, y: 450 }
    ];

    // Assign 6 unique fixed colors for cuisines
    for (let i = 0; i < 6; i++) {
        cuisineColors.push(color(random(100, 255), random(100, 255), random(100, 255)));
    }
}

function draw() {
    background(135, 205, 235);  // Sky blue background

    if (state === "whiteBoxes") {
        drawTitle();
        drawCuisines();
    } else if (state === "coloredBoxes") {
        drawColoredBoxes();
    } else if (state === "recipe") {
        drawRecipe(selectedCuisineIndex);
    }
}

function drawTitle() {
    fill(255, 105, 180);
    textSize(90);
    textAlign(CENTER, CENTER);
    textFont(gameFont);
    text("Types of Cuisines", width / 2, 50);
}

function drawCuisines() {
    textSize(70);
    textAlign(CENTER, TOP);
    textFont(gameFont);

    // Draw first set of boxes (white boxes) for cuisines
    for (let i = 0; i < boxes.length; i++) {
        let box = boxes[i];
        fill(255);  // White color for the boxes
        rect(box.x, box.y, 400, 270, 20);  // Draw the rectangle

        fill(255, 105, 180);  // Label color
        text(labels[i], box.x + 200, box.y + 20);  // Draw the label
    }
}

function drawColoredBoxes() {
    // Second set of boxes (colored boxes)
    for (let i = 0; i < boxes.length; i++) {
        let box = boxes[i];
        let isUnlocked = unlockedBoxes[i];  // Check if the current box is unlocked

        // If the box is unlocked, use the cuisine color
        if (isUnlocked) {
            fill(cuisineColors[i]);  // Each cuisine gets a unique color
        } else {
            fill(200);  // Grayed out if locked
        }

        rect(box.x, box.y, 400, 270, 20);  // Draw the rectangle for each box

        // Display "Locked" text for locked boxes
        if (!isUnlocked) {
            fill(100);
            textFont("Arial");  // Use a system font that supports emoji
            textAlign(CENTER, CENTER);  // Center text horizontally and vertically
            textSize(20);
            // Show "🔒 Locked" text and adjust position so it's centered
            text("🔒", box.x + 210, box.y + 140);  // Centered text
            text("Locked", box.x + 210, box.y + 230);  
        }
    }
}

function drawRecipe(index) {
    // Assuming you have some predefined recipe array
    let recipe = recipes[index];

    fill(255);
    rect(100, 100, 500, 600);  // Left side rectangle for the recipe
    rect(680, 100, 800, 600);  // Right side rectangle for the details

    textFont(gameFont);
    fill(0);  // Text color
    textSize(70);
    textAlign(LEFT, TOP);
    text(`Cuisine: ${recipe.name}`, 120, 120);
    text("Recipe:", 120, 200);
    text("Calories:", 700, 250);
    text("Servings:", 700, 350);
    text("Preparation Time:", 700, 450);
    text("Ingredients:", 700, 550);

    fill(255, 150, 100);
    text(recipe.recipe, 120, 280);
    text(recipe.calories, 1020, 250);
    text(recipe.servings, 1020, 350);
    text(recipe.prepTime, 1020, 450);
    textSize(50);
    let ingredientsText = recipe.ingredients.join(", ");
    text(ingredientsText, 1020, 550, 460, 600);  // Wrap text for ingredients
}

function mousePressed() {
    for (let i = 0; i < boxes.length; i++) {
        let box = boxes[i];

        if (
            mouseX >= box.x && mouseX <= box.x + 400 &&
            mouseY >= box.y && mouseY <= box.y + 270
        ) {
            if (state === "whiteBoxes") {
                selectedCuisineIndex = i;
                state = "coloredBoxes";  // Transition to colored boxes
                return;
            } else if (state === "coloredBoxes") {
                // Only allow the first box to be clicked if it's unlocked
                if (unlockedBoxes[i]) {
                    // Unlock the next boxes (based on the selected cuisine)
                    if (i < unlockedBoxes.length - 1) {
                        unlockedBoxes[i + 1] = true;
                    }
                    state = "recipe";  // Show the recipe for the selected cuisine
                    return;
                }
            }
        }
    }
}

