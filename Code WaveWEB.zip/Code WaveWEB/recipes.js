let recipes = [
    {
      name: "italian",
      recipe: "Spaghetti Carbonara",
      calories: "500 kcal",
      servings: "2",
      prepTime: "30 minutes",
      ingredients: ["Spaghetti", "Eggs", "Pancetta", "Parmesan", "Black Pepper"]
    },
    {
      name: "Mexican",
      recipe: "Tacos al Pastor",
      calories: "550 kcal",
      servings: "3",
      prepTime: "40 minutes",
      ingredients: ["Tortillas", "Pork", "Pineapple", "Onion", "Cilantro"]
    },
    {
      name: "Chinese",
      recipe: "Kung Pao Chicken",
      calories: "600 kcal",
      servings: "2",
      prepTime: "35 minutes",
      ingredients: ["Chicken", "Peanuts", "Bell Peppers", "Chili Peppers", "Soy Sauce"]
    },
    {
      name: "Thai",
      recipe: "Pad Thai",
      calories: "550 kcal",
      servings: "2",
      prepTime: "30 minutes",
      ingredients: ["Rice Noodles", "Tofu", "Peanuts", "Bean Sprouts", "Tamarind Sauce"]
    },
    {
      name: "Indian",
      recipe: "Butter Chicken",
      calories: "650 kcal",
      servings: "4",
      prepTime: "50 minutes",
      ingredients: ["Chicken", "Tomatoes", "Butter", "Cream", "Spices"]
    },
    {
      name: "Japanese",
      recipe: "Sushi Rolls",
      calories: "400 kcal",
      servings: "2",
      prepTime: "45 minutes",
      ingredients: ["Sushi Rice", "Nori", "Fish", "Avocado", "Cucumber"]
    }
  ];
  