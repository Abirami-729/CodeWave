
function DrawCanyons(t_canyons) {
    for (let i = 0; i < t_canyons.length; i++) {
        let t_canyon = t_canyons[i];

        noStroke();
        fill(245, 222, 179);
        rect(t_canyon.pos_x, t_canyon.pos_y, t_canyon.Width, 160);

        fill(210, 180, 140);
        triangle(t_canyon.pos_x, t_canyon.pos_y, t_canyon.pos_x + t_canyon.Width, t_canyon.pos_y, t_canyon.pos_x + t_canyon.Width / 2, t_canyon.pos_y + 160);

        //anchor point
        // fill(255, 0, 0);
        // ellipse(t_canyon.pos_x, t_canyon.pos_y, 10, 10);
    }
}

function CheckCanyons(t_canyons) {
    for (let i = 0; i < t_canyons.length; i++) {
        let t_canyon = t_canyons[i];
        if (gameChar_y == floorPos_y &&
            // check if game char is from the left of canyon
            gameChar_x - 20 > t_canyon.pos_x &&
            // check if game char is from the right of canyon
            gameChar_x + 20 < t_canyon.pos_x + t_canyon.Width) {

            isPlummeting = true;
            isLeft = false;
            isRight = false;
            screaming_sound.play();
        }
    }
}

//Draw the Clouds

function DrawClouds() {
    const cloudSpeed = 1;
    for (let i = 0; i < clouds.length; i++) {
        cloud = clouds[i];

        fill(220, 220, 220);
        ellipse(cloud.pos_x + 35, cloud.pos_y + 5, cloud.size + 20, cloud.size + 5);
        rect(cloud.pos_x, cloud.pos_y, cloud.size + 15, cloud.size - 10);
        ellipse(cloud.pos_x, cloud.pos_y + 25, cloud.size - 5, cloud.size - 10);
        ellipse(cloud.pos_x + 70, cloud.pos_y + 25, cloud.size - 5, cloud.size - 10);

        // Move the cloud
        cloud.pos_x += cloudSpeed;  // Move rightwards (adjust for direction)
        if (cloud.pos_x > 4000) {
            cloud.pos_x = -1200;
        };

        //anchor point
        // fill(255, 0, 0);
        // ellipse(cloud.pos_x, cloud.pos_y, 10, 10);

    }
}

//Draw the Mountains
function DrawMountains(t_mountain) {
    for (let i = 0; i < mountains.length; i++) {
        let t_mountain = mountains[i];
        push();
        fill(160, 0, 0);
        ellipse(t_mountain.pos_x, t_mountain.pos_y - 60, 40, 30);
        ellipse(t_mountain.pos_x + 30, t_mountain.pos_y - 70, 80, 50);
        ellipse(t_mountain.pos_x + 60, t_mountain.pos_y - 60, 40, 30);

        fill(160, 82, 45);
        quad(
            t_mountain.pos_x, t_mountain.pos_y - 70,
            t_mountain.pos_x + 60, t_mountain.pos_y - 70,
            t_mountain.pos_x + 180, t_mountain.pos_y + 185,
            t_mountain.pos_x - 120, t_mountain.pos_y + 185
        );

        fill(255, 215, 0);
        quad(
            t_mountain.pos_x, t_mountain.pos_y - 70,
            t_mountain.pos_x + 60, t_mountain.pos_y - 70,
            t_mountain.pos_x + 85, t_mountain.pos_y - 20,
            t_mountain.pos_x - 25, t_mountain.pos_y - 20
        );

        stroke(255, 215, 0);
        strokeWeight(7);
        line(t_mountain.pos_x - 30, t_mountain.pos_y + 20, t_mountain.pos_x - 10, t_mountain.pos_y - 20);
        line(t_mountain.pos_x + 90, t_mountain.pos_y + 20, t_mountain.pos_x + 70, t_mountain.pos_y - 20);
        strokeWeight(10);
        line(t_mountain.pos_x - 8, t_mountain.pos_y + 40, t_mountain.pos_x + 15, t_mountain.pos_y - 20);
        line(t_mountain.pos_x + 60, t_mountain.pos_y + 40, t_mountain.pos_x + 40, t_mountain.pos_y - 20);
        noStroke();
        pop();
    }
}


//Draw the Trees
function DrawTrees() {
    for (let i = 0; i < trees_x.length; i++) {
        let tree = trees_x[i];

        noStroke();
        fill(120, 100, 40);
        rect(tree[0], tree[1], 45, 90);

        fill(0, 155, 0);
        triangle(tree[0] - 35, tree[1] + 35, tree[0] + 25, tree[1] - 35, tree[0] + 75, tree[1] + 35);
        triangle(tree[0] - 35, tree[1], tree[0] + 25, tree[1] - 65, tree[0] + 75, tree[1]);
        triangle(tree[0] - 35, tree[1] - 35, tree[0] + 25, tree[1] - 95, tree[0] + 75, tree[1] - 35);

        //Decorating the Trees using Lines and  Different Coloured Baubles(Tree balls)
        fill(255, 0, 0);
        ellipse(tree[0], tree[1] - 7, 14, 14);
        stroke(255);
        line(tree[0] + 55, tree[1] - 55, tree[0] - 25, tree[1]);
        line(tree[0] + 60, tree[1] - 25, tree[0] - 25, tree[1] + 35);

        fill(255, 215, 0);
        ellipse(tree[0] + 40, tree[1], 14, 14);
        triangle(tree[0] + 15, tree[1] - 92, tree[0] + 25, tree[1] - 105, tree[0] + 35, tree[1] - 92);
        fill(173, 216, 230);
        ellipse(tree[0] + 7, tree[1] - 60, 14, 14);
        fill(255, 165, 0);
        ellipse(tree[0] + 40, tree[1] - 40, 14, 14);

        //anchor point
        // fill(255, 0, 0);
        // ellipse(tree[0], tree[1], 10, 10);
    }
}

//Draw the Collectables
function DrawCollectables(t_collectables) {
    for (let i = 0; i < t_collectables.length; i++) {
        let t_collectable = t_collectables[i];

        // Only draw the collectable if it hasn't been found
        if (!t_collectable.isFound) {
            push();
            fill(200, 0, 0);
            noStroke();
            ellipse(t_collectable.pos_x, t_collectable.pos_y - 10, t_collectable.size - 10, t_collectable.size - 20);
            ellipse(t_collectable.pos_x - 15, t_collectable.pos_y - 10, t_collectable.size - 20, t_collectable.size - 35);
            fill(255)
            ellipse(t_collectable.pos_x + 10, t_collectable.pos_y - 10, t_collectable.size - 33, t_collectable.size - 25);
    
            fill(255, 165, 0)
            rect(t_collectable.pos_x - 40, t_collectable.pos_y - 14, 20, 8)
            fill(200, 0, 0)
            ellipse(t_collectable.pos_x + 10, t_collectable.pos_y - 10, t_collectable.size - 43, t_collectable.size - 36);
    
            //Bone
            fill(240, 220, 190)
            rect(t_collectable.pos_x - 40, t_collectable.pos_y - 14, 20, 8)
            fill(240, 220, 190)
            ellipse(t_collectable.pos_x - 43, t_collectable.pos_y - 13, t_collectable.size - 40, t_collectable.size - 39);
            fill(240, 220, 190)
            ellipse(t_collectable.pos_x - 43, t_collectable.pos_y - 8, t_collectable.size - 40, t_collectable.size - 39);

            //anchor point
            // fill(255, 0, 0);
            // ellipse(t_collectable.pos_x, t_collectable.pos_y, 10, 10);
        }
    }
}

function CheckCollectables(t_collectables) {
    for (let i = 0; i < t_collectables.length; i++) {
        let t_collectable = t_collectables[i];
        // Only check if the collectable hasn't been found yet
        if (!t_collectable.isFound && dist(gameChar_x, gameChar_y, t_collectable.pos_x + 20, t_collectable.pos_y + 40) < 50) {
            t_collectable.isFound = true;
            textSize(40);
            text('+10', t_collectable.pos_x + 27, t_collectable.pos_y - 30);
            game_score += 10;
            fill(200, 200, 200);
            collecting_sound.play();
            collecting_sound.setVolume(0.2);
        }
    }
    // Score System
    textFont(gameFont);
    fill(255, 105, 180);
    textSize(78);
    textAlign(RIGHT, TOP);
    text("Score =" + game_score, gameChar_x - 320, 10);
    text("Lives =", gameChar_x - 360, 60);
    textFont('Segoe UI Emoji');
    textSize(30);
    text("❤️".repeat(lives), gameChar_x - 240, 90);
}

function renderFlagpole() {
    push();
    strokeWeight(5);
    stroke(180);
    line(flagpole.x_pos, floorPos_y, flagpole.x_pos, floorPos_y - 250);
    fill(255, 215, 0);
    noStroke();
    ellipse(flagpole.x_pos, floorPos_y - 250, 20, 20);

    triangle(
        flagpole.x_pos, flagpole.y_pos,
        flagpole.x_pos + 90, flagpole.y_pos + 30,
        flagpole.x_pos, flagpole.y_pos + 60
    );

    if (flagpole.isReached) {
        // Slowly move the flag upwards
        if (flagpole.y_pos > floorPos_y - 250) {
            flagpole.y_pos -= 1;
        }
    }
    pop();
}

function checkFlagpole() {
    let d = abs(gameChar_x - flagpole.x_pos);
    if (d < 15) {
        flagpole.isReached = true;
    }
}

function checkPlayerDie() {
    for (let i = 0; i < canyons.length; i++) {
        let canyon = canyons[i];
        if (gameChar_y == floorPos_y + 180 &&  // Character is falling
            gameChar_x > canyon.pos_x &&
            gameChar_x < canyon.pos_x + canyon.Width) {
            // Deduct a life when falling into a canyon
            lives -= 1;
            StartGame(); // Reset the character's position
        }
    }
}

//Draw Snowballs
function DrawSnowballs() {
    for (let i = 0; i < snowballs.length; i++) {
        let snowball = snowballs[i];

        fill(230, 240, 255);
        ellipse(snowball.pos_x + 35, snowball.pos_y + 5, snowball.size, snowball.size);
        snowball.pos_x = snowball.pos_x + (random(1, 4));
        snowball.pos_y = snowball.pos_y + 2;

        if (snowball.pos_y > height) {
            snowball.pos_y = random(-500, -50);
            snowball.pos_x = random(-2500, 2500);
        }
        //anchor point
        // fill(255, 0, 0);
        // ellipse(snowball.pos_x, snowball.pos_y, 10, 10);
    }
}

function DrawSnowman() {

    if (flagpole.isReached) {
        const snowman = {
            pos_x: 4840,
            pos_y: floorPos_y + 50
        };

        push();

        // Draw the body
        stroke(200);
        strokeWeight(1);
        fill(255);
        ellipse(snowman.pos_x, snowman.pos_y - 90, 90, 81);
        ellipse(snowman.pos_x, snowman.pos_y - 135, 68, 68);
        ellipse(snowman.pos_x, snowman.pos_y - 180, 45, 45);

        // Draw the carrot
        fill(237, 145, 33);
        triangle(snowman.pos_x, snowman.pos_y - 180, snowman.pos_x, snowman.pos_y - 168, snowman.pos_x + 18, snowman.pos_y - 172);

        // Draw eyes
        fill(0); // Black eyes
        ellipse(snowman.pos_x - 6, snowman.pos_y - 187, 6, 6);
        ellipse(snowman.pos_x + 6, snowman.pos_y - 187, 6, 6);

        // Draw the arms
        stroke(0);
        strokeWeight(4);
        line(snowman.pos_x - 24, snowman.pos_y - 130, snowman.pos_x - 55, snowman.pos_y - 150);
        line(snowman.pos_x + 24, snowman.pos_y - 130, snowman.pos_x + 55, snowman.pos_y - 150);
        noStroke();

        //Draw the Hat
        fill(50, 50, 50)
        rect(snowman.pos_x - 18, snowman.pos_y - 235, 37, 40)
        rect(snowman.pos_x - 30, snowman.pos_y - 205, 60, 10)
        fill(220, 20, 60);
        rect(snowman.pos_x - 18, snowman.pos_y - 220, 37, 10)

        pop();
    }
}

// Function to reset the character's position after losing a life
function StartGame() {
    // Reset character's position to the starting point
    gameChar_x = width / 2;
    gameChar_y = floorPos_y;

    // Reset any other relevant states
    isLeft = false;
    isRight = false;
    isFalling = false;
    isPlummeting = false;

    cameraPosX = 0;
}

