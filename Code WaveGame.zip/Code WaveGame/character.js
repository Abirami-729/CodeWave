//the game character
function DrawGameCharacter() {
    if (isLeft && isFalling) {
        //add your jumping - left code
        fill(190, 0, 0);
        stroke(100);
        rect(gameChar_x - 15, gameChar_y - 56, 28, 36);
        ellipse(gameChar_x, gameChar_y - 69, 24, 30);

        // Legs
        rect(gameChar_x - 15, gameChar_y - 20, 8, 20);
        rect(gameChar_x + 5, gameChar_y - 20, 8, 20);

        // Hands
        quad(gameChar_x - 25, gameChar_y - 33, gameChar_x - 23, gameChar_y - 23, gameChar_x - 14, gameChar_y - 40, gameChar_x - 14, gameChar_y - 55);
        rect(gameChar_x + 13, gameChar_y - 56, 8, 28);

        // Black stripe
        fill(0);
        stroke(100);
        ellipse(gameChar_x, gameChar_y - 69, 20, 24);
        rect(gameChar_x - 15, gameChar_y - 30, 28, 6);
        rect(gameChar_x - 4, gameChar_y - 55, 5, 25);

        //head
        fill(255);
        noStroke();
        ellipse(gameChar_x, gameChar_y - 74, 10, 12);
        stroke(100);

        fill(0)
        ellipse(gameChar_x, gameChar_y - 74, 6, 8);

        // Anchor point
        // fill(255, 0, 255);
        // ellipse(gameChar_x, gameChar_y, 5, 5);
    }
    else if (isRight && isFalling) {
        //add your jumping - right code
        fill(190, 0, 0);
        stroke(100);
        rect(gameChar_x - 15, gameChar_y - 56, 28, 36);
        ellipse(gameChar_x, gameChar_y - 69, 24, 30);

        // Legs
        rect(gameChar_x - 15, gameChar_y - 20, 8, 20);
        rect(gameChar_x + 5, gameChar_y - 20, 8, 20);

        // Hands
        rect(gameChar_x - 23, gameChar_y - 56, 8, 28);
        quad(gameChar_x + 25, gameChar_y - 33, gameChar_x + 23, gameChar_y - 23, gameChar_x + 14, gameChar_y - 40, gameChar_x + 14, gameChar_y - 55);

        // Black stripe
        fill(0);
        stroke(100);
        ellipse(gameChar_x, gameChar_y - 69, 20, 24);
        rect(gameChar_x - 15, gameChar_y - 30, 28, 6);
        rect(gameChar_x - 4, gameChar_y - 55, 5, 25);

        //head
        fill(255);
        noStroke();
        ellipse(gameChar_x, gameChar_y - 74, 10, 12);
        stroke(100);

        fill(0)
        ellipse(gameChar_x, gameChar_y - 74, 6, 8);

        // Anchor point
        // fill(255, 0, 255);
        // ellipse(gameChar_x, gameChar_y, 5, 5);

    }
    else if (onPlatform && isLeft || isLeft) {
        //add your walking left code
        // Tail
        fill(190, 0, 0);
        stroke(100);
        rect(gameChar_x - 15, gameChar_y - 56, 28, 36);
        ellipse(gameChar_x, gameChar_y - 69, 24, 30);

        // Legs
        rect(gameChar_x - 15, gameChar_y - 20, 8, 20);
        rect(gameChar_x + 5, gameChar_y - 20, 8, 20);

        // Hands
        quad(gameChar_x - 25, gameChar_y - 33, gameChar_x - 23, gameChar_y - 23, gameChar_x - 14, gameChar_y - 40, gameChar_x - 14, gameChar_y - 55);
        rect(gameChar_x + 13, gameChar_y - 56, 8, 28);

        // Black stripe
        fill(0);
        stroke(100);
        ellipse(gameChar_x, gameChar_y - 69, 20, 24);
        rect(gameChar_x - 15, gameChar_y - 30, 28, 6);
        rect(gameChar_x - 4, gameChar_y - 55, 5, 25);

        //head
        fill(255);
        noStroke();
        triangle(gameChar_x - 6, gameChar_y - 70, gameChar_x, gameChar_y - 80, gameChar_x + 6, gameChar_y - 70);
        stroke(100);

        fill(0)
        triangle(gameChar_x - 3, gameChar_y - 72, gameChar_x, gameChar_y - 76.5, gameChar_x + 3, gameChar_y - 72);

        // Anchor point
        // fill(255, 0, 255);
        // ellipse(gameChar_x, gameChar_y, 5, 5);
    }
    else if (onPlatform && isRight || isRight) {
        //add your walking right code
        // stroke(1)
        fill(190, 0, 0);
        stroke(100);
        rect(gameChar_x - 15, gameChar_y - 56, 28, 36);
        ellipse(gameChar_x, gameChar_y - 69, 24, 30);

        // Legs
        rect(gameChar_x - 15, gameChar_y - 20, 8, 20);
        rect(gameChar_x + 5, gameChar_y - 20, 8, 20);

        // Hands
        rect(gameChar_x - 23, gameChar_y - 56, 8, 28);
        quad(gameChar_x + 25, gameChar_y - 33, gameChar_x + 23, gameChar_y - 23, gameChar_x + 14, gameChar_y - 40, gameChar_x + 14, gameChar_y - 55);

        // Black stripe
        fill(0);
        stroke(100);
        ellipse(gameChar_x, gameChar_y - 69, 20, 24);
        rect(gameChar_x - 15, gameChar_y - 30, 28, 6);
        rect(gameChar_x - 4, gameChar_y - 55, 5, 25);

        //head
        fill(255);
        noStroke();
        triangle(gameChar_x - 6, gameChar_y - 70, gameChar_x, gameChar_y - 80, gameChar_x + 6, gameChar_y - 70);
        stroke(100);

        fill(0)
        triangle(gameChar_x - 3, gameChar_y - 72, gameChar_x, gameChar_y - 76.5, gameChar_x + 3, gameChar_y - 72);

        // Anchor point
        // fill(255, 0, 255);
        // ellipse(gameChar_x, gameChar_y, 5, 5);

    }
    else if (isFalling || onPlatform) {
        //add your jumping facing forwards code
        // stroke(1)
        fill(190, 0, 0);
        stroke(100);
        rect(gameChar_x - 15, gameChar_y - 56, 28, 36);
        ellipse(gameChar_x, gameChar_y - 69, 24, 30);

        // Legs
        rect(gameChar_x - 15, gameChar_y - 20, 8, 20);
        rect(gameChar_x + 5, gameChar_y - 20, 8, 20);

        // Hands
        quad(gameChar_x - 25, gameChar_y - 33, gameChar_x - 23, gameChar_y - 23, gameChar_x - 14, gameChar_y - 40, gameChar_x - 14, gameChar_y - 55);
        quad(gameChar_x + 25, gameChar_y - 33, gameChar_x + 23, gameChar_y - 23, gameChar_x + 14, gameChar_y - 40, gameChar_x + 14, gameChar_y - 55);

        //Black stripe
        fill(0);
        stroke(100);
        ellipse(gameChar_x, gameChar_y - 69, 20, 24);
        rect(gameChar_x - 15, gameChar_y - 30, 28, 6);
        rect(gameChar_x - 4, gameChar_y - 55, 5, 25);

        //head
        fill(255);
        noStroke();
        ellipse(gameChar_x, gameChar_y - 74, 10, 12);
        stroke(100);

        fill(0)
        ellipse(gameChar_x, gameChar_y - 74, 6, 8);

        // Anchor point
        // fill(255, 0, 255);
        // ellipse(gameChar_x, gameChar_y, 5, 5);
    }
    else {
        //add your standing front facing code
        // stroke(1)
        fill(190, 0, 0);
        stroke(100);
        rect(gameChar_x - 15, gameChar_y - 56, 28, 36);
        ellipse(gameChar_x, gameChar_y - 69, 24, 30);

        // Legs
        rect(gameChar_x - 15, gameChar_y - 20, 8, 20);
        rect(gameChar_x + 5, gameChar_y - 20, 8, 20);

        // Hands
        rect(gameChar_x - 23, gameChar_y - 56, 8, 28);
        rect(gameChar_x + 13, gameChar_y - 56, 8, 28);

        // Black stripe
        fill(0);
        stroke(100);
        ellipse(gameChar_x, gameChar_y - 69, 20, 24);
        rect(gameChar_x - 15, gameChar_y - 30, 28, 6);
        rect(gameChar_x - 4, gameChar_y - 55, 5, 25);

        //head
        fill(255);
        noStroke();
        rect(gameChar_x - 5, gameChar_y - 78, 10, 10);
        stroke(100);

        fill(0)
        rect(gameChar_x - 3, gameChar_y - 76, 6, 6);

        // Anchor point
        // fill(255, 0, 255);
        // ellipse(gameChar_x, gameChar_y, 5, 5);

    }
}