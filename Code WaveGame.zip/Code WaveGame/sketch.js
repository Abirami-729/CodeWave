//variables Used
let gameChar_x;
let gameChar_y;
let floorPos_y;
let isLeft;
let isRight;
let isFalling;
let isPlummeting;
let cameraPosX;
let canyons = [];
let clouds = [];
let trees_x;
let collectables = [];
let mountains = [];
let snowballs = [];
let gameFont;
let game_score = 0;
let flagpole;
let lives = 3;
let gameImage;
let jump_Sound;
let screaming_sound;
let collecting_sound;
let game_music;
let platforms;
let enemies;
let onPlatform;
let confettiSystem;

//Inserting external files into game 
function preload() {
	// Use the relative path for the preload
	gameFont = loadFont("assets/Akhenaton-LYLD.ttf");
	gameImage = loadImage("assets/Skull.jpg");
	soundFormats('mp3', 'wav');
	jump_Sound = loadSound("assets/Sound_1.mp3");
	screaming_sound = loadSound("assets/Sound_2.mp3");
	game_music = loadSound("assets/Sound_3.mp3");
	collecting_sound = loadSound("assets/Sound_4.mp3");
}

function setup() {
	createCanvas(1024, 576);
	floorPos_y = height * 3 / 4;
	gameChar_x = width / 2;
	gameChar_y = floorPos_y;
	isLeft = false;
	isRight = false;
	isFalling = false;
	isPlummeting = false;
	onPlatform = false;
	cameraPosX = 0;
	game_music.loop();
	game_music.setVolume(0.1);

	snowballs = [
		{ pos_x: random(-1000, 1500), pos_y: random(-500, -300), size: random(15, 35) },
		{ pos_x: random(-1000, 1500), pos_y: random(-500, -300), size: random(15, 35) },
		{ pos_x: random(-1000, 1500), pos_y: random(-500, -300), size: random(15, 35) },
		{ pos_x: random(-1000, 1500), pos_y: random(-500, -300), size: random(15, 35) },
		{ pos_x: random(1500, 4000), pos_y: random(-500, -300), size: random(15, 35) },
		{ pos_x: random(1500, 4000), pos_y: random(-500, -300), size: random(15, 35) },
		{ pos_x: random(1500, 4000), pos_y: random(-500, -300), size: random(15, 35) },
		{ pos_x: random(1500, 4000), pos_y: random(-500, -300), size: random(15, 35) }
	];

	clouds = [
		{ pos_x: -1200, pos_y: 60, size: 60 },
		{ pos_x: -500, pos_y: 70, size: 60 },
		{ pos_x: 300, pos_y: 50, size: 60 },
		{ pos_x: 1000, pos_y: 100, size: 60 },
		{ pos_x: 1800, pos_y: 70, size: 60 },
		{ pos_x: 2500, pos_y: 50, size: 60 },
		{ pos_x: 3300, pos_y: 80, size: 60 },
	];

	canyons = [
		{ pos_x: -1000, pos_y: floorPos_y, Width: 300 },
		{ pos_x: -400, pos_y: floorPos_y, Width: 270 },
		{ pos_x: 100, pos_y: floorPos_y, Width: 180 },
		{ pos_x: 600, pos_y: floorPos_y, Width: 130 },
		{ pos_x: 1000, pos_y: floorPos_y, Width: 160 },
		{ pos_x: 1400, pos_y: floorPos_y, Width: 260 },
		{ pos_x: 2000, pos_y: floorPos_y, Width: 120 },
		{ pos_x: 2400, pos_y: floorPos_y, Width: 270 },
		{ pos_x: 3000, pos_y: floorPos_y, Width: 150 },
		{ pos_x: 3400, pos_y: floorPos_y, Width: 280 },
		{ pos_x: 4000, pos_y: floorPos_y, Width: 170 }
	];

	trees_x = [
		[-600, floorPos_y - 90],
		[400, floorPos_y - 90],
		[750, floorPos_y - 90],
		[1200, floorPos_y - 90],
		[1800, floorPos_y - 90],
		[2700, floorPos_y - 90],
		[3300, floorPos_y - 90],
		[4300, floorPos_y - 90],
		[4950, floorPos_y - 90]
	];

	collectables = [
		{ pos_x: -550, pos_y: floorPos_y , size: 50, isFound: false },
		{ pos_x: 0, pos_y: floorPos_y, size: 50, isFound: false },
		{ pos_x: 800, pos_y: floorPos_y, size: 50, isFound: false },
		{ pos_x: 1300, pos_y: floorPos_y - 230, size: 50, isFound: false },
		{ pos_x: 1750, pos_y: floorPos_y , size: 50, isFound: false },
		{ pos_x: 2150, pos_y: floorPos_y, size: 50, isFound: false },
		{ pos_x: 2330, pos_y: floorPos_y - 230, size: 50, isFound: false },
		{ pos_x: 2800, pos_y: floorPos_y, size: 50, isFound: false },
		{ pos_x: 3300, pos_y: floorPos_y, size: 50, isFound: false },
		{ pos_x: 3800, pos_y: floorPos_y, size: 50, isFound: false }
	];

	mountains = [
		{ pos_x: 50, pos_y: floorPos_y - 185, height: 300, width: 150 },
		{ pos_x: 950, pos_y: floorPos_y - 185, height: 360, width: 200 },
		{ pos_x: 2200, pos_y: floorPos_y - 185, height: 300, width: 150 },
		{ pos_x: 2330, pos_y: floorPos_y - 185, height: 300, width: 150 },
		{ pos_x: 2900, pos_y: floorPos_y - 185, height: 300, width: 170 },
		{ pos_x: 3750, pos_y: floorPos_y - 185, height: 290, width: 130 },
		{ pos_x: 3900, pos_y: floorPos_y - 185, height: 360, width: 200 }
	];

	flagpole = { isReached: false, x_pos: 4650, y_pos: floorPos_y - 60 };

	platforms = [];
	platforms.push(createPlatforms(-400, floorPos_y - 60, 120, -400, -200));
	platforms.push(createPlatforms(1250, floorPos_y - 120, 120, 1250, 1350));
	platforms.push(createPlatforms(1450, floorPos_y - 60, 120, 1450, 1550));
	platforms.push(createPlatforms(2300, floorPos_y - 130, 120, 2300, 2400));
	platforms.push(createPlatforms(2400, floorPos_y - 60, 120, 2400, 2500));
	platforms.push(createPlatforms(3400, floorPos_y - 60, 120, 3400, 3500));

	enemies = []
	enemies.push(new Enemy(330, floorPos_y, 100));
	enemies.push(new Enemy(1800, floorPos_y, 90));
	enemies.push(new Enemy(2300, floorPos_y - 130, 50));
	enemies.push(new Enemy(2800, floorPos_y, 90));
	enemies.push(new Enemy(3800, floorPos_y, 80));

	confettiSystem = new ParticleSystem(createVector(1050, 130)); // Initialize system
	confettiSystem = new ParticleSystem(createVector(2650, 130)); // Initialize system
	confettiSystem = new ParticleSystem(createVector(3650, 130)); // Initialize system
	confettiSystem = new ParticleSystem(createVector(4650, 130)); // Initialize system
}

function draw() {

	//To implement Middle scrolling
	cameraPosX = gameChar_x - width / 2

	if (game_score >= 60) {
		background(70, 80, 80); // Night sky
	}

	else if (game_score >= 30) {
		background(35, 119, 164); // Dusk sky
	}

	else {
		background(135, 206, 250); // Evening sky
	}

	noStroke();
	fill(112, 192, 72);
	rect(0, floorPos_y, width, height - floorPos_y + 10); //draw grass 
	fill(230, 240, 255);
	rect(0, floorPos_y + 35, width, height - floorPos_y + 10); //draw snowy ground

	push();
	translate(-cameraPosX, 0);

	//Functions Used

	DrawCanyons(canyons);
	CheckCanyons(canyons);
	DrawClouds();
	DrawMountains();
	DrawTrees();
	DrawCollectables(collectables);
	CheckCollectables(collectables);
	renderFlagpole();
	checkPlayerDie();
	DrawGameCharacter();

	//Extra Game Elements Used
	DrawSnowballs();
	DrawSnowman();

	//Restricted Area
	textFont("Bangers");
	fill(180, 0, 0);
	textSize(30);
	text("RESTRICTED ZONE", -715, 480);

	//Draw Platforms
	for (let i = 0; i < platforms.length; i++) {
		platforms[i].draw();
		platforms[i].update();
	}

	//Draw Enemies
	for (let i = 0; i < enemies.length; i++) {
		enemies[i].draw();

		let isContact =
			enemies[i].checkContact(gameChar_x, gameChar_y);

		if (isContact) {
			if (lives > 0) {
				lives -= 1;
				StartGame();
				break;
			}
		}
	}

	// Run the confetti system (updates and draws particles)
	confettiSystem.run();

	//Display the "Game Over" text
	if (lives < 1) {
		if (gameImage) {
			image(gameImage, 0, 0, width, height);  // Display image at specific position
		}
		game_music.pause();
		textFont(gameFont);
		textSize(100);
		textAlign(CENTER, CENTER);
		fill(255, 150, 150);
		text("Score =" + game_score, gameChar_x + 220, 190);
		text("Game Over", gameChar_x + 220, 250);
		text("Press space to continue", gameChar_x + 220, 310);
		textSize(50);
		return;
	}

	//Congratulatory message
	if (flagpole.isReached == true) {
		game_music.pause();
		textFont(gameFont);
		fill(255, 182, 193);
		textSize(60);
		text("Congrats", gameChar_x + 250, 190);
		textSize(100);
		textAlign(CENTER, CENTER);
		text("Score = " + game_score, gameChar_x, 20);
		text("Level Complete", gameChar_x, 80);
		text("Press space to continue", gameChar_x, 140);
		textSize(50);
		confettiSystem.addParticle();
		return;
	}

	pop();

	///////INTERACTION CODE//////////
	//Conditional statements to move the game character below here

	if (isPlummeting) {
		gameChar_y += 6;
	}

	if (gameChar_y < floorPos_y) {
		let isContact = false;
		onPlatform = false;
		let platformSpeed = 0; // Store the platform's speed

		for (let i = 0; i < platforms.length; i++) {
			if (platforms[i].checkContact(gameChar_x, gameChar_y) == true) {
				isContact = true;
				onPlatform = true;
				platformSpeed = platforms[i].speed;
				break;
			}
		}
		if (isContact == false) {
			gameChar_y += 1;
			isFalling = true;
		}
		else {
			//if the character is on the platform, then the platform movement is added 
			gameChar_x += platformSpeed;
		}
	}
	else {
		isFalling = false;
		onPlatform = false;
	}

	if (isLeft == true) {
		gameChar_x -= 2.8;
	}

	else if (isRight == true) {
		gameChar_x += 2.8;
	}

	if (flagpole.isReached == false) {
		checkFlagpole();
	}
}

//Creating Platforms Using Factory Pattern
function createPlatforms(x, y, length, minX, maxX) {
	const p = {
		x: x,
		y: y,
		length: length,
		minX: minX,
		maxX: maxX,
		speed: 2,

		draw: function () {
			push();
			//draw the sledge body
			noStroke();
			fill(255, 80, 80);
			rect(this.x, this.y, this.length, 12);
			quad(this.x, this.y, this.x + 40, this.y, this.x + 25, this.y - 15, this.x, this.y - 25);
			triangle(this.x + 120, this.y, this.x + 90, this.y, this.x + 90, this.y - 15);

			//the legs of the sledge
			stroke(255, 215, 0);
			strokeWeight(4);
			line(this.x + 30, this.y + 12, this.x + 10, this.y + 24);
			line(this.x + 90, this.y + 12, this.x + 110, this.y + 24);
			line(this.x, this.y + 24, this.x + 130, this.y + 24);

			//Draw the anchor point
			// fill(255,0,0);
			// ellipse(this.x,this.y,5,5);
			noStroke();
			pop();
		},

		update: function () {
			this.x += this.speed;

			// Reverse direction when hitting the minX or maxX
			if (this.x > this.maxX || this.x < this.minX) {
				this.speed *= -1;
			}
		},
		// Check if player is on the platform
		checkContact: function (gc_x, gc_y) {
			if (gc_x > this.x && gc_x < this.x + this.length) {
				let d = this.y - gc_y;
				if (d >= 0 && d < 5) {
					return true;
				}
			}
			return false;
		}
	}
	return p;
}

//Creating Enemies Using Constructor function
class Enemy {
	constructor(x, y, range) {
		this.x = x;
		this.y = y;
		this.range = range;
		this.currentX = x;
		this.inc = 1;
	}
	update() {
		this.currentX += this.inc;

		if (this.currentX >= this.x + this.range) {
			this.inc = -1.7;
		}
		else if (this.currentX < this.x) {
			this.inc = 1.7;
		}
	}

	draw() {
		this.update();

		// Draw the bomb
		fill(80, 80, 80);
		ellipse(this.currentX + 0, this.y - 15, 32, 32);
		fill(40, 40, 40);
		quad(this.currentX + 8, this.y - 27, this.currentX + 12, this.y - 23, this.currentX + 19, this.y - 33, this.currentX + 14, this.y - 36);
		fill(210);
		ellipse(this.currentX - 5, this.y - 23, 6, 9);

		//flame
		fill(255, 80, 0);
		ellipse(this.currentX + 24, this.y - 48, 5, 9);
		strokeWeight(1.5);
		stroke(0);
		line(this.currentX + 14, this.y - 31, this.currentX + 24, this.y - 45);
		noStroke();

		// Draw the anchor point
		// fill(255,0,0);
		// ellipse(this.currentX,this.y-20,5,5);
	}

	checkContact = function (gc_x, gc_y) {
		const d = dist(gc_x, gc_y, this.currentX, this.y - 20);
		if (d < 40) {
			screaming_sound.play();
			return true;
		}
		return false;
	}
}

//Creating Confetti Using Particle System

class ParticleSystem {
	constructor(origin) {
		this.origin = origin.copy();
		this.particles = [];
	}

	addParticle() {
		const angle = random(TWO_PI);
		const speed = random(1, 3);

		let p = {
			position: this.origin.copy(),
			size: random(5, 12),
			color: color(random(255), random(255), random(255), 200),
			lifespan: 200
		};

		p.speedX = cos(angle) * speed;
		p.speedY = sin(angle) * speed;

		this.particles.push(p);
	}

	run() {
		for (let i = this.particles.length - 1; i >= 0; i--) {
			let p = this.particles[i];
			this.update(p);
			this.display(p);

			p.lifespan -= 1;
			if (p.lifespan < 0) {
				this.particles.splice(i, 1);
			}
		}
	}

	update(p) {
		// Update the particle's position
		p.position.x += p.speedX;
		p.position.y += p.speedY;
		p.speedY += 0.03;
	}

	display(p) {
		noStroke();
		fill(p.color);
		ellipse(p.position.x, p.position.y, p.size, p.size);
	}
}

// Function to Reset the Game Elements
function ResetGame() {
	game_score = 0;
	lives = 3;
	gameChar_x = width / 2;
	gameChar_y = floorPos_y;
	isLeft = false;
	isRight = false;
	isFalling = false;
	isPlummeting = false;
	flagpole.y_pos = floorPos_y - 60;
	flagpole.isReached = false;

	for (let i = 0; i < collectables.length; i++) {
		collectables[i].isFound = false;
	}
}

function keyPressed() {
	// if statements to control the animation of the character when
	// keys are pressed.

	if (keyCode == 32) {
		//Restart function by pressing Space
		ResetGame();
		game_music.pause();
		game_music.play();
	}

	if (isPlummeting) {
		return;
	}

	if (keyCode == 37) {
		console.log("Left arrow");
		isLeft = true;
	}

	else if (keyCode == 39) {
		console.log("Right arrow");
		isRight = true;
	}

	else if (keyCode == 38) {
		//ensure that the character only jump when it is touching the ground
		if (gameChar_y >= floorPos_y || onPlatform) {
			console.log("Up arrow");
			gameChar_y -= 80;
			jump_Sound.play();
		}
	}
}

function keyReleased() {
	// if statements to control the animation of the character when
	// keys are released.

	if (keyCode == 37) {
		console.log("Left arrow");
		isLeft = false;
	}

	else if (keyCode == 39) {
		console.log("Right arrow");
		isRight = false;
	}
}

//THE END OF CODE