// var mouseX
// var mouseY

// function setup() {
// 	createCanvas(windowWidth, windowHeight);
// }
// // function draw() {
// // 	background(135, 206, 235);
// // }
// function mousePressed() {
// 	var btn = document.getElementById("startBtn");

// 	if (btn) {
// 		var rect = btn.getBoundingClientRect();

// 		if (
// 			mouseX >= rect.left &&
// 			mouseX <= rect.right &&
// 			mouseY >= rect.top &&
// 			mouseY <= rect.bottom
// 		) {
// 			window.location.href = "newpage.html";
// 		}

// 	}

// }

